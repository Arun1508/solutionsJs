CREATE TABLE comments (
     comment_id MEDIUMINT NOT NULL AUTO_INCREMENT,
     comment_text TEXT,
     creation_date DATETIME,
     created_user_id MEDIUMINT,
     post_id MEDIUMINT,
     PRIMARY KEY (comment_id),
     FOREIGN KEY (created_user_id) REFERENCES user(user_id)ON DELETE CASCADE,
     FOREIGN KEY (post_id) REFERENCES post(post_id)ON DELETE CASCADE
);

