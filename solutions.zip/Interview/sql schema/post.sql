CREATE TABLE post (
     post_id MEDIUMINT NOT NULL AUTO_INCREMENT,
     post TEXT,
     creation_date DATETIME,
     created_user_id MEDIUMINT,
     PRIMARY KEY (post_id),
     FOREIGN KEY (created_user_id) REFERENCES user(user_id)ON DELETE CASCADE
);

