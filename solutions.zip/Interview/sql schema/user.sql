CREATE TABLE user (
     user_id MEDIUMINT NOT NULL AUTO_INCREMENT,
     name CHAR(30) NOT NULL,
     created_date DATE,
     address TEXT,
     PRIMARY KEY (user_id)
);

