const express = require('express');
const {getUsers, postUser, getUserByID, putUser, deleteUser} = require('../controllers/user_controller');

const router = express.Router();
//read
router.get('/', getUsers);
router.get('/:userId', getUserByID);
//create
router.post('/', postUser);
//update
router.put('/:userId', putUser);
//delete
router.delete('/:userId', deleteUser);
module.exports = router;