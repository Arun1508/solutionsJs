const express = require('express');
const {getPosts, getPostId,postPost, putPost, deletePostId} = require('../controllers/post_controller');
const {getComments, getCommentId,postComment, putComment, deleteCommentById} = require('../controllers/comment_controller');
const router = express.Router();
//read
router.get('/', getPosts);
router.get('/:postId', getPostId);
router.get('/:postId/comment', getComments);
router.get('/:postId/comment/:commentId', getCommentId);
//create
router.post('/', postPost);
router.post('/:postId/comment', postComment);
//update
router.put('/:postId', putPost);
router.put('/:postId/comment/:commentId', putComment);
//delete
router.delete('/:postId', deletePostId);
router.delete('/:postId/comment/:commentId',deleteCommentById);

module.exports = router;