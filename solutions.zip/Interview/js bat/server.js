const express = require('express');
const bodyparser = require('body-parser');

const {conn} =require('./util/db');
const userRouter = require("./router/user_route");
const postRouter = require("./router/post_route");

const port = 1234;
var app = express();
 conn.connect((err)=> {
    if(!err)
    console.log('Connection Established Successfully');
    else
    console.log('Connection Failed!'+ JSON.stringify(err,undefined,2));
});
app.use(bodyparser.json());
app.use('/user', userRouter);
app.use('/post', postRouter);

app.get('/',(req,res)=> {
    res.status(200).json({'note':'welcome'});
});


app.listen(port, console.log(`Listening to post ${port}`));