const {conn} =require('../util/db');

module.exports.postComment = async(req,res) =>{
    var userData = req.body;
    var sql = `INSERT INTO comments 
    (comment_text, creation_date, created_user_id,post_id) 
    VALUES (?,?,?,?)`;
    await conn.query(sql,
        [userData['commentText'], 
        new Date().toISOString().slice(0, 19).replace('T', ' '), 
        userData['createdUserId'],
        req.params.postId
    ], 
        function(err,result){
        if (!err){
            console.log("Number of records inserted: " + result);
            res.status(201).json({'result': result});
            
        } else {
            res.status(500).json({'error': err});
        }
    } );
};

module.exports.getComments = async(req,res) => {
    await conn.query(`select comments.comment_id as commentId,
                             comments.comment_text as comment,
                             comments.creation_date as createdDate,
                             comments.post_id as PostId,
                             comments.created_user_id as createdUser,
                             user.name as createdUserName
                             from comments join user on comments.created_user_id = user.user_id 
                             where comments.post_id = ?`,[req.params.postId],(err, rows, fields) => {
        if (!err)
            res.status(200).send(rows);
        else
            res.status(500).send({error: err});
    });
};

module.exports.getCommentId = async(req,res) => {
    await conn.query(`select comments.comment_id as commentId,
                             comments.comment_text as comment,
                             comments.creation_date as createdDate,
                             comments.post_id as PostId,
                             comments.created_user_id as createdUser,
                             user.name as createdUserName
                             from comments join user on comments.created_user_id = user.user_id 
                             where comments.comment_id = ?`,[req.params.commentId],(err, rows, fields) => {
        if (!err)
            res.status(200).send(rows[0]);
        else
            res.status(500).send({error: err});
    });
};

module.exports.putComment = async(req,res) => {
    var comment_id = req.params.commentId;
    var userData = req.body;
    var sql = "update comments set comment_text = ? where comment_id = ?";
    await conn.query(sql,[ userData['commentText'], comment_id], function(err,result){
        if (!err){
            console.log("Number of records inserted: " + result.affectedRows);
            res.status(201).json({'result': result});
        } else {
            res.status(500).json({'error': err});
        }
    } );
}

module.exports.deleteCommentById = async(req,res) => {
    var comment_id = req.params.commentId;
    var sql = "delete from comments where comment_id = ?";
    await conn.query(sql,[ comment_id], function(err,result){
        if (!err){
            console.log("Number of records inserted: " + result.affectedRows);
            res.status(201).json({'result': result});
        } else {
            res.status(500).json({'error': err});
        }
    } );
}