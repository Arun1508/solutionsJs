const {conn} =require('../util/db');

module.exports.getUsers = async(req,res) =>{
        
        await conn.query('SELECT * from user',(err, rows, fields) => {
            if (!err)
                res.status(200).send(rows);
            else
                res.status(500).send({error: err});
        });
};

module.exports.getUserByID = async(req,res) =>{
        
    await conn.query(`SELECT * from user where user_id = ?`,[req.params.userId] ,(err, rows, fields) => {
        if (!err)
            res.status(200).send(rows);
        else
            res.status(500).send({error: err});
    });
};


module.exports.postUser = async(req,res) =>{
    var userData = req.body;
    var sql = "INSERT INTO user (name, created_date, address) VALUES (?,?,?)";
    await conn.query(sql,[userData['name'], new Date().toISOString().slice(0, 19).replace('T', ' '), userData['address']], function(err,result){
        if (err){
            res.status(500).json({'error': error});
        } else {
            console.log("Number of records inserted: " + result.affectedRows);
            res.status(201).json({'result': result.affectedRows});
        }
    } );
};

module.exports.putUser = async(req,res) => {
    var user_id = req.params.userId;
    var userData = req.body;
    var sql = "update user set address = ?, name = ? where user_id = ?";
    await conn.query(sql,[ userData['address'], userData['name'], user_id], function(err,result){
        if (!err){
            console.log("Number of records inserted: " + result.affectedRows);
            res.status(201).json({'result': result.affectedRows});
        } else {
            res.status(500).json({'error': err});
        }
    } );
}

module.exports.deleteUser = async(req,res) => {
    var sql = "delete from user where user_id = ?";
    await conn.query(sql,[ req.params.userId], function(err,result){
        if (!err){
            console.log("Number of records inserted: " + result.affectedRows);
            res.status(201).json({'result': result.affectedRows});
        } else {
            res.status(500).json({'error': err});
        }
    } );   
}