const {conn} =require('../util/db');

module.exports.postPost = async(req,res) =>{
    var userData = req.body;
    var sql = "INSERT INTO post (post, creation_date, created_user_id) VALUES (?,?,?)";
    await conn.query(sql,
        [userData['post'], 
        new Date().toISOString().slice(0, 19).replace('T', ' '), 
        userData['createdUserId']], 
        function(err,result){
        if (!err){
            console.log("Number of records inserted: " + result.affectedRows);
            res.status(201).json({'result': result.affectedRows});
            
        } else {
            res.status(500).json({'error': err});
        }
    } );
};

module.exports.putPost = async(req,res) =>{
    var userData = req.body;
    var sql = "update post set post = ? where post_id = ?";
    await conn.query(sql,
        [userData['post'], req.params.postId], 
        function(err,result){
        if (!err){
            console.log("Number of records inserted: " + result.affectedRows);
            res.status(201).json({'result': result.affectedRows});
            
        } else {
            res.status(500).json({'error': err});
        }
    } );
};

module.exports.getPosts = async(req,res) =>{
        
    await conn.query(`SELECT post.post_id as id,
                    post.post as post,
                    post.creation_date as createdDate,
                    post.created_user_id as createdUserId,
                    user.name as CreatedUserName
                      from post join user on post.created_user_id = user.user_id`,(err, rows, fields) => {
        if (!err)
            res.status(200).send(rows);
        else
            res.status(500).send({error: err});
    });
};

module.exports.getPostId = async(req,res) =>{
        
    await conn.query(`SELECT post.post_id as id,
                    post.post as post,
                    post.creation_date as createdDate,
                    post.created_user_id as createdUserId,
                    user.name as CreatedUserName
                from post join user on post.created_user_id = user.user_id
                where post.post_id = ?`, [req.params.postId],(err, rows, fields) => {
        if (!err)
            res.status(200).send(rows);
        else
            res.status(500).send({error: err});
    });
};

module.exports.deletePostId = async(req,res) => {
    var sql = "delete from post where post_id = ?";
    await conn.query(sql,
        [req.params.postId], 
        function(err,result){
        if (!err){
            console.log("Number of records inserted: " + result.affectedRows);
            res.status(201).json({'result': result.affectedRows});
            
        } else {
            res.status(500).json({'error': err});
        }
    } );   
}