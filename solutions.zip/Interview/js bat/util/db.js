const mysql = require('mysql');



module.exports.conn = mysql.createConnection({
            host:'localhost',
            user:'root',
            password:'Sam@1233321!',
            database: "test"
        });
    