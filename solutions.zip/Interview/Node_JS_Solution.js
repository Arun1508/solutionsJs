dataSet1 = [13, 1, 5, 8, 6];
dataSet2 = [
    {
        Name:"Bonnie Jennings",
        age:  50,
        occupation: "Driver"
    },
    {
        Name: "Aysha Mathis",
        age:  27,
        occupation: "Teacher"
    },
    {
        Name: "Tianna Dorsey",
        age:  35,
        occupation: "Player"
    },
    {
        Name: "Fleur Chandler",
        age:  49,
        occupation: "Teacher"
    },
    {
        Name: "Imogen Robinson",
        age:  60,
        occupation: "Driver"
    },
    {
        Name: "Sienna Zuniga",
        age:  17,
        occupation: "Athlete"
    },
    {
        Name: "Kimberley Petty",
        age:  50,
        occupation: "Driver"
    },
    {
        Name: "Elizabeth Donaldson",
        age:  22,
        occupation: "Athlete"
    },
    {
        Name: "Priya Haines",
        age:  50,
        occupation: "Athlete"
    },
    {
        Name: "Claudia Glenn",
        age:  50,
        occupation: "Architect"
    },
]

// sorting ds1 and ds2
function sortFunction(ds1, ds2){
    for(let i = 0; i < ds1.length; i++){
      for(let j = 0; j < ( ds1.length - i -1 ); j++){
        if(ds1[j] > ds1[j+1]){
          let temp = ds1[j]
          ds1[j] = ds1[j + 1]
          ds1[j+1] = temp
        }
      }
    }
    for(let i = 0; i < ds2.length; i++){
        for(let j = 0; j < ( ds2.length - i -1 ); j++){
          if(ds2[j].age > ds2[j+1].age){
            let temp = ds2[j]
            ds2[j] = ds2[j + 1]
            ds2[j+1] = temp
          }else if(ds2[j].age == ds2[j+1].age && ds2[j].Name > ds2[j+1].Name ){
            let temp = ds2[j]
            ds2[j] = ds2[j + 1]
            ds2[j+1] = temp
            
          }
        }
      }
    
    console.log(ds1);
    console.log(ds2);
   }

// filter < 38
function filterList(ds2){
  let result = [];
  for(let i = 0; i < ds2.length; i++){
    if ( ds2[i].age < 38 ){
      result.push(ds2[i])
    }
  }
  console.log(`filters`, result);
}

// calculate dob
function transformArrayCalculateDOB(ds2){
  
  for(let i = 0; i < ds2.length; i++){
    var ddmm = '1/1';
    var yyyy= 2021 - ds2[i].age;
    ds2[i].dateOfBirth =  ddmm+"/"+yyyy;
  }
  console.log(ds2)
}

function groupList(ds2){
  let result = {}
  for(let i = 0; i < ds2.length; i++){
    result[ds2[i].occupation] = result[ds2[i].occupation] || [];
    result[ds2[i].occupation].push(ds2[i]);
  }
  //console.log(result);
  return result;
}

function maxMinAvg(ds1,ds2){
  let minDs1 = ds1[0], maxDs1 = ds1[0], avgDs1 = 0,
      minDs2 = ds2[0].age, maxDs2 = ds2[0].age,
       avgDs2 = 0;
  for(let i=1; i < ds1.length; i++){
    if(minDs1 > ds1[i]) minDs1 = ds1[i];
    if(maxDs1 < ds1[i]) maxDs1 = ds1[i];
    avgDs1 += ds1[i];
  }
  avgDs1 = avgDs1/ds1.length;

  for(let i=0; i< ds2.length; i++){
    if(minDs2 > ds2[i].age) minDs2 = ds2[i].age;
    if(maxDs2 < ds2[i].age) maxDs2 = ds2[i].age;
    avgDs2 += ds2[i].age;
  }
  avgDs2 = avgDs2/ds2.length;
  console.log(minDs1, maxDs1, avgDs1);
  console.log(minDs2, maxDs2, avgDs2);
}

function countOccp(ds2){
  result = groupList(ds2);
  for(let i in result){
    console.log(i,result[i].length);
  }
}

//sortFunction(dataSet1, dataSet2);
//filterList(dataSet2)
//transformArrayCalculateDOB(dataSet2);
//groupList(dataSet2);
//maxMinAvg(dataSet1,dataSet2);
//countOccp(dataSet2);